const user_table = 'email_folders' ; 

module.exports = function makeCreatDefaultFolder({mysql}){
    return async function creatDefaultFolder(obj) {
        const {name , userId } = obj ; 
        try {
            await mysql.quert(`INSERT INTO email_folders (name, user_id ,provider_id ) VALUES ( ? , ? , null);`, [name ,userId])
        }
        catch(err)
        {
            throw err ; 
        }
    }
}