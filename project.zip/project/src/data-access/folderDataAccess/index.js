const mysql = require('../sql-connection') ; 

const makeCreatFolder = require('./creatFolder') ; 
const creatFolder =makeCreatFolder({
    mysql,
}) ; 

const folderDb = {creatFolder} ; 
module.exports = folderDb ; 