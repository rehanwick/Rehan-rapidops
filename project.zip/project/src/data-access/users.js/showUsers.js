const users_table = "users";

module.exports = function makeShowUsersData({mysql}) {

    return async function createDemoEntry() {
    let result ; 
    try {
       [result] =  await mysql.query(`select * from ${users_table} `);
    } catch (err) {
      throw err;
    }
    return result;
  }
}


