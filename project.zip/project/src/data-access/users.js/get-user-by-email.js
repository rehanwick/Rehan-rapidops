const user_table = "users";
module.exports = function makeGetUserByEmail({ mysql }) {
  return async function getUserByEmail(obj) {
    const { email } = obj;
    let user;
    try {
      [user] = await mysql.execute(`select * FROM users WHERE email = ?;`, [
        email,
      ]);
    } catch (err) {
      console.log(err);
      throw err;
    }
    return user;
  };
};
