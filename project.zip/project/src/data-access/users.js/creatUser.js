const user_table = 'users' ; 

module.exports = function makeCreatUser({mysql}){
    return async function creatUser(obj) {
        const {name , email , password} = obj ;
        try{
            await mysql.query(`INSERT INTO users (name, password ,email , access_token , refresh_token ) VALUES ( ? , ? , ? , null ,null);`, [name,password,email] )
        }
        catch(err)
        {
            throw err ; 
        }
    }
}