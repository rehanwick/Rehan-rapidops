const mysql = require("../sql-connection");

const makeShowUsersData = require("./showUsers");
const showUsers = makeShowUsersData({
    mysql,
});

const makeCreatUser = require("./creatUser")
const creatUser = makeCreatUser({
    mysql, 
})

const makeGetUserByEmail = require("./get-user-by-email") ; 
const getUserByEmail = makeGetUserByEmail({
    mysql, 
})

const userDb = { showUsers ,creatUser , getUserByEmail};

module.exports = userDb;
