const userDb = require("./users.js");

const folderDb = require("./folderDataAccess") ; 

module.exports = { ...folderDb , ...userDb} ;
