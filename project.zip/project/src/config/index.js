const config = require('./server-config') ; 


module.exports = config ;  