const config = {
    localhost : {
        port : '3000' 
    }
}


module.exports = config ;