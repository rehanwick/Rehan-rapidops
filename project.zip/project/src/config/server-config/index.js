const config = require('./development') ; 

module.exports = config ; 
