const express = require("express");
const router = express.Router();
const controller = require("./controller/users-controller");

router.get("/users", controller.showUsersController);
router.post("/user" , controller.creatUserController) ; 



module.exports = router;
