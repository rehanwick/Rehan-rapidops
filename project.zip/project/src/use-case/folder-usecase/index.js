const Joi = require('joi') ; 
const {creatFolder } = require("../../data-access") ; 

const makeCreatFolderUsecase = require('./creatFolderUsecase') ; 
const creatFolder = makeCreatFolderUsecase({
    Joi , 
    creatFolder
}) ; 

module.exports = {makeCreatFolderUsecase} ; 