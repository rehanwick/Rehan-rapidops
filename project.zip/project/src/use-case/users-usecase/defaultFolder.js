module.exports = function makeCreatDefaultFolder({ 
    Joi,
    creatDefaultFolder 
}) {
  return async function creatDefaultFolder() {
    try {
        await creatDefaultFolder() ; 
    } 
    catch (e) {
        throw e ; 
    }
  };
};
