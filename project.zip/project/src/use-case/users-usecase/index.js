const Joi = require("joi");

const {showUsers , creatUser , getUserByEmail } = require("../../data-access/index");

const makeShowUsersUsecase = require("./show-users-usecase");
 

const showUsersUsecase = makeShowUsersUsecase({
  Joi,
  showUsers,
});

const makeCreatUserUsecase = require('./creatuser-usecase') ; 
const creatUserUsecase = makeCreatUserUsecase({
  Joi , 
  creatUser , 
  getUserByEmail
})

module.exports = {showUsersUsecase , creatUserUsecase };
