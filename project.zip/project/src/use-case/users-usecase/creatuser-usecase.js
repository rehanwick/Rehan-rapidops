module.exports = function makeCreatUserUsecase({
  Joi,
  creatUser,
  getUserByEmail,
}) {
  return async function creatUserUsecase(obj) {
    try {
      const user = await getUserByEmail(obj);
      console.log(user);
      if (user) {
        throw new Error(`User already exist with email ${obj.email} `);
      }
      await creatUser(obj);
    } catch (e) {
      console.log(e);
      throw e;
    }
  };
};
