const Joi = require("joi");
const {showUsersUsecase , creatUserUsecase } = require("../../use-case");

const makeShowUsersController = require("./show-users");
const showUsersController = makeShowUsersController({
  Joi,
  showUsersUsecase,
});

const makeCreatUserController = require('./creat-user') ; 
const creatUserController = makeCreatUserController({
  Joi , 
  creatUserUsecase
})


module.exports = { showUsersController, creatUserController };
